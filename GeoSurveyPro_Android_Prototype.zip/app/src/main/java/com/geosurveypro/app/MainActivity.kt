package com.geosurveypro.app

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.*

data class SurveyPoint(
    val id: String, val easting: Double, val northing: Double,
    val elevation: Double, val description: String, val time: String
)

class MainActivity : Activity() {
    private val points = mutableListOf<SurveyPoint>()
    private lateinit var status: TextView
    private lateinit var listText: TextView
    private lateinit var projectInput: EditText
    private lateinit var idInput: EditText
    private lateinit var eastInput: EditText
    private lateinit var northInput: EditText
    private lateinit var elevInput: EditText
    private lateinit var descInput: EditText
    private lateinit var areaResult: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadPoints()
        showHome()
    }

    private fun showHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 22, 22, 22)
            setBackgroundColor(0xFFF5F7F6.toInt())
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val title = TextView(this).apply {
            text = "GeoSurvey Pro"
            textSize = 28f
            setTextColor(0xFF176B55.toInt())
            gravity = Gravity.CENTER_VERTICAL
        }
        content.addView(title)
        content.addView(TextView(this).apply {
            text = "Offline surveying prototype • Version 0.1.0"
            textSize = 13f
            setPadding(0, 4, 0, 18)
        })
        status = TextView(this).apply {
            text = "GNSS: Ba a haɗa receiver ba tukuna"
            textSize = 14f
            setPadding(12, 12, 12, 12)
            setBackgroundColor(0xFFE3EEE9.toInt())
        }
        content.addView(status)
        val connect = Button(this).apply {
            text = "Duba Bluetooth / GNSS"
            setOnClickListener { checkBluetooth() }
        }
        content.addView(connect)
        content.addView(section("Sabon Survey Point"))
        projectInput = edit("Project name", "My Survey")
        idInput = edit("Point ID", "P001")
        eastInput = edit("Easting (m)", "")
        northInput = edit("Northing (m)", "")
        elevInput = edit("Elevation (m)", "0")
        descInput = edit("Description", "Boundary point")
        listOf(projectInput, idInput, eastInput, northInput, elevInput, descInput).forEach { content.addView(it) }
        content.addView(Button(this).apply {
            text = "Ajiye Point"
            setOnClickListener { savePoint() }
        })
        content.addView(section("Lissafin Area"))
        content.addView(TextView(this).apply {
            text = "Shigar da aƙalla points 3 a jere. Ana amfani da Easting/Northing a cikin coordinate system ɗaya."
            textSize = 13f
        })
        areaResult = TextView(this).apply {
            textSize = 16f
            setPadding(0, 8, 0, 8)
        }
        content.addView(Button(this).apply {
            text = "Lissafa Area daga duk points"
            setOnClickListener { calculateArea() }
        })
        content.addView(areaResult)
        content.addView(section("Points da aka ajiye"))
        listText = TextView(this).apply { textSize = 13f; setPadding(0, 6, 0, 6) }
        content.addView(listText)
        content.addView(Button(this).apply {
            text = "Fitar da CSV"
            setOnClickListener { exportCsv() }
        })
        content.addView(TextView(this).apply {
            text = "\nLura: Wannan prototype ne. Haɗin Bluetooth na Palm3 da karɓar NMEA/RTK data ba a kammala ba; dole ne a tabbatar da protocol ɗin receiver kafin a dogara da shi a aikin filaye."
            textSize = 12f
            setTextColor(0xFF8A4B08.toInt())
            setPadding(0, 14, 0, 14)
        })
        scroll.addView(content)
        root.addView(scroll)
        setContentView(root)
        refreshList()
    }

    private fun section(text: String) = TextView(this).apply {
        this.text = text
        textSize = 18f
        setTextColor(0xFF176B55.toInt())
        setPadding(0, 22, 0, 8)
    }

    private fun edit(hintText: String, value: String): EditText = EditText(this).apply {
        hint = hintText
        setText(value)
        textSize = 15f
        singleLine = true
    }

    private fun savePoint() {
        try {
            val id = idInput.text.toString().trim()
            require(id.isNotEmpty()) { "Shigar da Point ID." }
            require(points.none { it.id.equals(id, true) }) { "Wannan Point ID yana nan tuni." }
            val e = eastInput.text.toString().toDouble()
            val n = northInput.text.toString().toDouble()
            val z = elevInput.text.toString().ifBlank { "0" }.toDouble()
            val p = SurveyPoint(
                id, e, n, z, descInput.text.toString().trim(),
                SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
            )
            points.add(p)
            savePoints()
            idInput.setText("P%03d".format(points.size + 1))
            eastInput.setText(""); northInput.setText("")
            refreshList()
            Toast.makeText(this, "An ajiye point $id", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Duba bayanai: ${e.message ?: "ba daidai ba"}", Toast.LENGTH_LONG).show()
        }
    }

    private fun calculateArea() {
        if (points.size < 3) {
            areaResult.text = "Ana buƙatar points 3 ko fiye."
            return
        }
        var sum = 0.0
        for (i in points.indices) {
            val a = points[i]
            val b = points[(i + 1) % points.size]
            sum += a.easting * b.northing - b.easting * a.northing
        }
        val sqm = abs(sum) / 2.0
        areaResult.text = "Area: ${"%.3f".format(sqm)} m²\nHectares: ${"%.5f".format(sqm / 10000.0)} ha\nPerimeter: ${"%.3f".format(perimeter())} m\n\nDole points su kasance cikin tsarin kewaye da fili, ba a gauraye ba."
    }

    private fun perimeter(): Double {
        if (points.size < 2) return 0.0
        var total = 0.0
        for (i in points.indices) {
            val a = points[i]
            val b = points[(i + 1) % points.size]
            total += hypot(b.easting - a.easting, b.northing - a.northing)
        }
        return total
    }

    private fun refreshList() {
        if (!::listText.isInitialized) return
        listText.text = if (points.isEmpty()) "Babu points tukuna." else points.joinToString("\n\n") {
            "${it.id}  E: ${it.easting}  N: ${it.northing}  Z: ${it.elevation}\n${it.description} • ${it.time}"
        }
    }

    private fun savePoints() {
        val arr = JSONArray()
        points.forEach { p ->
            arr.put(JSONObject().apply {
                put("id", p.id); put("easting", p.easting); put("northing", p.northing)
                put("elevation", p.elevation); put("description", p.description); put("time", p.time)
            })
        }
        File(filesDir, "points.json").writeText(arr.toString())
    }

    private fun loadPoints() {
        try {
            val f = File(filesDir, "points.json")
            if (!f.exists()) return
            val arr = JSONArray(f.readText())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                points.add(SurveyPoint(o.getString("id"), o.getDouble("easting"),
                    o.getDouble("northing"), o.optDouble("elevation", 0.0),
                    o.optString("description", ""), o.optString("time", "")))
            }
        } catch (_: Exception) { }
    }

    private fun exportCsv() {
        if (points.isEmpty()) {
            Toast.makeText(this, "Babu points da za a fitar.", Toast.LENGTH_SHORT).show()
            return
        }
        val csv = buildString {
            append("PointID,Easting,Northing,Elevation,Description,Timestamp\n")
            points.forEach {
                append("\"${it.id}\",${it.easting},${it.northing},${it.elevation},")
                append("\"${it.description.replace("\"", "\"\"")}\",\"${it.time}\"\n")
            }
        }
        val file = File(getExternalFilesDir(null), "GeoSurveyPro_points.csv")
        file.writeText(csv)
        Toast.makeText(this, "An fitar da CSV: ${file.absolutePath}", Toast.LENGTH_LONG).show()
    }

    private fun checkBluetooth() {
        try {
            val manager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
            val adapter: BluetoothAdapter? = manager.adapter
            if (adapter == null) {
                status.text = "Bluetooth bai samuwa a wannan wayar ba."
                return
            }
            if (Build.VERSION.SDK_INT >= 31 &&
                checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN), 501)
                status.text = "Ka ba manhajar izinin Bluetooth, sannan ka sake gwadawa."
                return
            }
            status.text = if (adapter.isEnabled) {
                "Bluetooth yana kunne. Palm3 ba a haɗa shi kai tsaye ba tukuna; haɗin data protocol zai biyo baya."
            } else {
                "Bluetooth a kashe yake. Kunna Bluetooth a Settings sannan ka sake gwadawa."
            }
        } catch (e: SecurityException) {
            status.text = "Ana buƙatar izinin Bluetooth."
        }
    }
}
