# GeoSurvey Pro — Android Prototype

## Abin da ke aiki a wannan prototype
- Ajiye survey points (Point ID, Easting, Northing, Elevation, description).
- Ajiye bayanai a wayar (offline).
- Lissafin polygon area da perimeter daga points da aka shigar.
- Fitar da coordinate points zuwa CSV.
- Duba ko Bluetooth yana kunne da kuma neman permission.

## Abin da bai kammala ba
- Haɗin Kilichain Palm3 kai tsaye da karɓar NMEA/RTK data.
- Stakeout, COGO, traverse adjustment, CAD/DXF, PDF plan, da map layers.
- Wannan ba a shirye yake don amfani da shi wajen final cadastral survey ba.

## Yadda za a gina APK
1. Buɗe project ɗin a Android Studio.
2. Bari Gradle sync ya kammala.
3. Zaɓi Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Za a sami APK a `app/build/outputs/apk/debug/` idan build ya yi nasara.

## Muhimmin gargadi
A tabbatar da calculations da independent survey examples kafin amfani da su a aikin ƙwararru. Area calculation na amfani da jerin points kamar yadda aka shigar; points dole su kewaye polygon cikin tsari daidai.
